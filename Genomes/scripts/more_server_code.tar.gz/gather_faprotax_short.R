# Quick and dirty script to recover FAPROTAX GENOMES that are still not downloaded.

## READ FAPROTAX GENOME DB
require(magrittr)

read.table("FAPROTAX_genome_metadata.tsv",header = T)->GENOME

list.files("FAPROTAX_Ordered_Genome/",pattern = "GCF.*K.*",full.names = F,include.dirs=F,no..=T) %>% gsub(pattern = "_KEGG.tsv",replacement = "",perl = T) %>% sort %>% unique %>% as.data.frame %>% setNames(nm = "Genomes") ->Positive_Genomes

subset(GENOME,subset = !assembly_accession %in% Positive_Genomes$Genomes) -> Negative_Genomes

rm(GENOME)

aggregate(x = Negative_Genomes[c("assembly_accession","species_taxid")],by = list(Negative_Genomes$species_taxid),FUN =function(x)sample(x,1)) -> Selected_Genomes
subset(Negative_Genomes,subset = assembly_accession %in% Selected_Genomes$assembly_accession) %>% unique -> Selected_Genomes

write.table(Selected_Genomes,file = "FAPROTAX_short_genome_metadata.tsv",sep = "\t",row.names = F,quote = F)

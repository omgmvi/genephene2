#!/bin/bash

#./D2VSentences.R MDB_Ordered_Genome/ ".*KEGG.*\\.tsv" "./" "MDB_D2Vs_KEGG.tsv" &> MDB_D2Vs_KEGG.log &
suffix='_Ordered_Genome'
for directory in *_Ordered_Genome;
do
	for ortho in {'KEGG','COG','pFam'};
	do	
		DB=${directory%"$suffix"}
		printf $directory'\".*'$ortho'.*\\\\.tsv\"''\"./\"'${DB^^}'_D2V_'$ortho'.tsv'${DB^^}'_D2V_'${ortho^^}'.log''\n' 
		./D2VSentences.R $directory '.*'$ortho'.*\.tsv' './' ${DB^^}'_D2V_'$ortho'.tsv' &> ${DB^^}'_D2V_'${ortho^^}'.log' &

	done
done

# Odin Moron Garcia 

# Start: 7th Sept 2021

# Goal: Build an script that merge a bed file with their corresponding COG, KEGG Orthologs and pFamA entries to get a ordered chromosome (like in ordered tuple) with the ortholog functional classificationin position.



######### FUNCTION LIBRARY ########


## Factory function to generate the needed 'mergers'

generate_merger <- function(by.x,by.y,selection,new_names){

	function(BED_file,Ortholog_file){
		setNames(merge(BED_file,Ortholog_file,by.x = by.x,by.y = by.y,all=F,sort = F)[,selection],nm = new_names)
	}
}

get_files<-function(glob,...){
	function(){
		read.table(file.path(Folder,grep(x = list.files(Folder),pattern = glob,value = T)),sep = "\t",...)
	}
}

save_files <- function(endname){
	function(object,folder,basename){
		filename <- paste0(basename,"_",endname,".tsv")
		filename <- sub(x=filename,pattern = ".*\\/(.*)$",replacement = paste0(folder,"\\1"))
		print(filename)
		write.table(x= object, file = filename,sep = "\t",row.names=F)
	}
}

#procedures 
check_file_exist <-function(){
	#check file exists and are unique
	stopifnot(all(apply(test <-Vectorize(grepl,vectorize.args="pattern")(pattern = c(bed_glob,cog_glob,KEGG_glob,pFam_glob), x= list.files(Folder)),2,any)))
	stopifnot(all(apply(test,2,sum)==1))
}

get_cog   <- get_files(cog_glob,header =T)
get_kegg  <- get_files(KEGG_glob,header = F,skip=1,comment.char = "",quote = "")
get_pfam  <- get_files(pFam_glob,header =T)
get_bed   <- get_files(bed_glob,header =F)

#To check the order
#melt_cog  <- generate_merger("Name","Query",c("Name","Subject","Start","End","Contig"),c("Contig_name","Ortholog_name","Start","End","Contig"))
#melt_kegg <- generate_merger("Name","ORF",c("Name","KO","Start","End","Contig"),c("Contig_name","Ortholog_name","Start","End","Contig"))
#melt_pfam <- generate_merger("Name","Gene",c("Name","Pfam_entry","Start","End","Contig"),c("Contig_name","Ortholog_name","Start","End","Contig"))
melt_cog  <- generate_merger("Name","Query",c("Name","Subject"),c("Contig_name","Ortholog_name"))
melt_kegg <- generate_merger("Name","ORF",c("Name","KO"),c("Contig_name","Ortholog_name"))
melt_pfam <- generate_merger("Name","Gene",c("Name","Pfam_entry"),c("Contig_name","Ortholog_name"))

save_files("COG") -> save_cog
save_files("KEGG")-> save_kegg
save_files("pFam")-> save_pfam

#### GLOBAL VARIABLES ###

FOLDER <- "GenePhene2_Genomes/"
OUTPUT_FOLDER <- "GenePhene2_Ordered_Genome/"

bed_glob <- "\\.bed"
cog_glob <- "_cogs_best_hits.tsv"
KEGG_glob <- "_KEGG_best_hits.tsv"
pFam_glob <- "_pfamA_best_hits.tsv"
######### SCRIPT #####

Folders <- list.dirs(FOLDER,recursive = F)
if(exists(OUTPUT_FOLDER)){dir.create(OUTPUT_FOLDER)}

for (Folder in Folders){
	check_file_exist()
	get_bed()->BED
	names(BED) <- c("Contig","Start","End","Name")
	get_cog()->COG
	melt_cog(BED,COG)->COG
	save_cog(COG,OUTPUT_FOLDER,Folder)
	get_kegg()->KEGG
	names(KEGG) <-c("ORF","KO","Threshold","Score1","Score2","KO_definition")
	melt_kegg(BED,KEGG)->KEGG
	save_kegg(KEGG,OUTPUT_FOLDER,Folder)
	get_pfam()->PFAM
	melt_pfam(BED,PFAM)->PFAM
	save_pfam(PFAM,OUTPUT_FOLDER,Folder)
}


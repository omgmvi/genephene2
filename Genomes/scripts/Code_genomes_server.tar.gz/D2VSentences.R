#!/usr/bin/env Rscript

# This script aim to build the "sentences" from genomes to make the Doc2Vec genomes
# Every "BED-like" file, that is the files with the ordered genome, having still the contig name and position in it, will be read
# so each line contain the genome name and a single contig. Now, the name of the contig or the position is irrelevant but the genes need to remain in order


# To make it conformant with other parts of the code the interface of the script will be :

# INPUT :
#	BagOfWords_Genome.py <FOLDER> <GLOB> <OUTPUT_FOLDER> <OUTPUT_FILE>

# where the FOLDER is the root folder where the genomes are expected to be
# and <GLOB> is a pattern for ls (linux command for list files) that is a subset of the files in a directory.

# Each of these files must have the following pattern:
#	"Contig_name"   "Ortholog_name"
#	"NZ_JJOR01000049.1_2"   "COG0118"
#	"NZ_JJOR01000049.1_3"   "COG1973"
#	"NZ_JJOR01000049.1_4"   "COG1030"
#OUTPUT:
#	GCF_000979335.1	COG0118 COG1973 COG1030	
#	GCF_000021425.1 ...

# This code really would benefit of having an index of genes in the sense of HD comsumption
# In principle without quotes and tab based column separation


######### PREAMBLE ########

## LIBRARIES

## GLOBAL VARIABLES

## FUNCTIONS

check_folder <- function(folder){
	stopifnot(dir.exists(folder))
}
get_files<-function(folder,glob){
	dir(path = folder,pattern=glob,all.files=F,recursive=F,full.names=F,ignore.case=F,include.dirs=F,no.. =T)
}
check_filelist <- function(x){stopifnot(Negate(is.empty)(x))}

is.empty <- function(object){length(object) == 0}
###########################
## SETUP ##

args = commandArgs(trailingOnly=TRUE)

if(length(args) !=4){
	FOLDER <- "./MDB_Ordered_Genome"
	GLOB <- ".*COG.*\\.tsv"
	OUTPUT_FOLDER <- "./"
	FILE <- "test.tsv"
}else{
	FOLDER <- args[1]
	GLOB <- args[2]
	OUTPUT_FOLDER <- args[3]
	FILE <- args[4]
}

##
print("first checks")
print(FOLDER)
print(GLOB)
print(OUTPUT_FOLDER)
print(FILE)
print("these were the options")
check_folder(FOLDER)
list_of_files <- get_files(FOLDER,GLOB)
check_filelist(list_of_files)
#TODO
	# READ FILES ONE BY ONE
		# CHECK THE CONTENTS ARE AS EXPECTED
		# COUNT THE REPEATED GENES
	# MELT THE COUNTED GENES PER FILE

#cur_file <- sample(x = list_of_files,size = 1)
total <- list()
i <- 1
for(cur_file in list_of_files){
	print(paste0("file #: ",i," from ",length(list_of_files)))
	i<- i +1 

	sub(pattern="(GCF_.*\\.\\d+)_.*",x = cur_file,replacement="\\1")->Genome

	fHandle <-file(file.path(FOLDER,cur_file),open = "rt")

	header <- scan(text = readLines(con = fHandle, n =1),sep = "\t",what = "char",quiet = T)

	if(!setequal(header,c("Contig_name", "Ortholog_name"))){close(fHandle);next}

	firstline <- 0

	while(Negate(is.empty)(line <- scan(text = readLines(con = fHandle, n =1),sep = "\t",what = "char",quiet = T)))
	{
		if(!firstline)
		{
			genes <- c()
			prev_contig <- gsub(x = line[1],pattern = "^(.*)_\\w+$",replacement = "\\1",perl = T)
			genes <- c(genes,line[2])
			firstline <- 1
		}

		cur_contig <- gsub(x = line[1],pattern = "^(.*)_\\w+$",replacement = "\\1",perl = T)
		
		if(prev_contig != cur_contig)
		{
			total <- c(total,list(c(Genome,genes)))
			genes <- c()
			prev_contig <- cur_contig
			genes <- c(genes,line[2])
		}else
		{
			genes <- c(genes,line[2])
		}
		
	}
	total <- c(total,list(c(Genome,genes)))
	close(fHandle)
}

#write.table(x = total,file = file.path(OUTPUT_FOLDER,FILE),row.names = F,quote = F,na = "0",sep = "\t")
fHandle <-file(file.path(OUTPUT_FOLDER,FILE),open = "at")
lapply(total,function(aline,fileHandle){writeLines(text = paste0(aline,collapse="\t"),con = fHandle,sep = "\n")},fileHandle = fHandle)
close(fHandle)
